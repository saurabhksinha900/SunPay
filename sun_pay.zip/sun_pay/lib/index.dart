// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/otp/otp_widget.dart' show OtpWidget;
export '/pages/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/pages/onboarding/onboarding_widget.dart' show OnboardingWidget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
export '/pages/bookings/bookings_widget.dart' show BookingsWidget;
export '/pages/search/search_widget.dart' show SearchWidget;
export '/pages/search_turfs/search_turfs_widget.dart' show SearchTurfsWidget;
export '/pages/createprofile/createprofile_widget.dart'
    show CreateprofileWidget;
export '/pages/updateprofile/updateprofile_widget.dart'
    show UpdateprofileWidget;
export '/pages/te2/te2_widget.dart' show Te2Widget;
export '/pages/te3/te3_widget.dart' show Te3Widget;
export '/pages/selectlocation/selectlocation_widget.dart'
    show SelectlocationWidget;
export '/pages/location/location_widget.dart' show LocationWidget;
export '/pages/savedaddresses/savedaddresses_widget.dart'
    show SavedaddressesWidget;
export '/pages/addaddress/addaddress_widget.dart' show AddaddressWidget;
export '/pages/logout/logout_widget.dart' show LogoutWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/commercial/commercial_widget.dart' show CommercialWidget;
export '/pages/booktimeslot/booktimeslot_widget.dart' show BooktimeslotWidget;
export '/pages/bookingconfirmed/bookingconfirmed_widget.dart'
    show BookingconfirmedWidget;
export '/pages/industrial/industrial_widget.dart' show IndustrialWidget;
