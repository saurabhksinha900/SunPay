// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<bool> logoutFromSession(String sessionId, UsersRecord userDoc) async {
  final userRef = userDoc.reference;

  try {
    // 🔄 Get latest user data
    final freshSnapshot = await userRef.get();
    final freshUser = UsersRecord.fromSnapshot(freshSnapshot);

    List<String> sessionIds = List<String>.from(freshUser.sessionIds);
    List<String> activeSessionIds =
        List<String>.from(freshUser.activeSessionIds);
    List<String> sessionLogoutTimes =
        List<String>.from(freshUser.sessionLogouttimes ?? []);

    print('Logging out session: $sessionId');
    print('AppState session: ${FFAppState().currentSessionId}');
    print('Active session IDs: $activeSessionIds');

    final index = sessionIds.indexOf(sessionId);
    if (index != -1) {
      while (sessionLogoutTimes.length < sessionIds.length) {
        sessionLogoutTimes.add('');
      }
      sessionLogoutTimes[index] = DateTime.now().toIso8601String();
    }

    final wasActive = activeSessionIds.remove(sessionId);

    if (wasActive) {
      await userRef.update({
        'active_session_ids': activeSessionIds,
        'session_logouttimes': sessionLogoutTimes,
        'active_sessions': FieldValue.increment(-1),
        'last_logout_time': FieldValue.serverTimestamp(),
      });
    }

    if (sessionId == FFAppState().currentSessionId) {
      FFAppState().currentSessionId = '';
      FFAppState().deviceModel = '';
      FFAppState().devicePlatform = '';
      return true;
    }

    return false;
  } catch (e) {
    print('Error logging out session: $e');
    return false;
  }
}
