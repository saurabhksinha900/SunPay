// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:speech_to_text/speech_to_text.dart' as stt;

import 'package:permission_handler/permission_handler.dart';

Future<void> requestMicPermission() async {
  var status = await Permission.microphone.status;
  if (!status.isGranted) {
    await Permission.microphone.request();
  }
}

stt.SpeechToText _speech = stt.SpeechToText();

Future<String> startSpeechToText() async {
  bool available = await _speech.initialize();
  if (available) {
    String resultText = '';
    await _speech.listen(
      onResult: (result) {
        if (result.finalResult) {
          resultText = result.recognizedWords;
        }
      },
      listenFor: Duration(seconds: 5),
    );

    await Future.delayed(Duration(seconds: 6));
    _speech.stop();
    return resultText;
  } else {
    return 'Speech not available';
  }
}
