// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:io' show Platform;
import 'package:device_info_plus/device_info_plus.dart';

Future generateSessionInfo() async {
  final deviceInfo = DeviceInfoPlugin();
  String model = 'Unknown';
  String platform = 'Unknown';

  try {
    if (kIsWeb) {
      model = 'Web Browser';
      platform = 'Web';
    } else if (Platform.isAndroid) {
      final info = await deviceInfo.androidInfo;
      model = info.model ?? 'Android Device';
      platform = 'Android';
    } else if (Platform.isIOS) {
      final info = await deviceInfo.iosInfo;
      model = info.utsname.machine ?? 'iOS Device';
      platform = 'iOS';
    }
  } catch (e) {
    print('Device info error: $e');
  }

  final rawSessionId = DateTime.now().millisecondsSinceEpoch.toString();
  final sessionId = '${rawSessionId}_${model}_${platform.replaceAll(' ', '')}';

  // Save to AppState for use in FlutterFlow Firestore Update step
  FFAppState().currentSessionId =
      DateTime.now().millisecondsSinceEpoch.toString();
  FFAppState().deviceModel = model;
  FFAppState().devicePlatform = platform;
}
