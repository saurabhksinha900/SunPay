// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future removeCurrentSession(UsersRecord userDoc) async {
  final sessionId = FFAppState().currentSessionId;
  if (sessionId.isEmpty) return;

  final index = userDoc.sessionIds.indexOf(sessionId);
  if (index == -1) return;

  final updatedActiveSessionIds = List<String>.from(userDoc.activeSessionIds);
  updatedActiveSessionIds.remove(sessionId);

  final updatedLogoutTimes =
      List<String>.from(userDoc.sessionLogouttimes ?? []);

  // Ensure logoutTimes list has the same length as sessionIds
  while (updatedLogoutTimes.length < userDoc.sessionIds.length) {
    updatedLogoutTimes.add('');
  }

  // Update the logout time at the corresponding index
  updatedLogoutTimes[index] = DateTime.now().toIso8601String();

  await FirebaseFirestore.instance
      .collection('users')
      .doc(userDoc.reference.id)
      .update({
    'session_ids': userDoc.sessionIds,
    'session_devices': userDoc.sessionDevices,
    'session_platforms': userDoc.sessionPlatforms,
    'session_logintimes': userDoc.sessionLogintimes,
    'last_logout_time': FieldValue.serverTimestamp(),
    'active_session_ids': updatedActiveSessionIds,
    'active_sessions': FieldValue.increment(-1),
    'session_logouttimes': updatedLogoutTimes,
  });

  FFAppState().currentSessionId = '';
}
