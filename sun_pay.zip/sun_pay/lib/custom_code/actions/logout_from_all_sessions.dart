// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';

Future<bool> logoutFromAllSessions(UsersRecord userDoc) async {
  try {
    final userRef = userDoc.reference;

    final sessionIds = List<String>.from(userDoc.sessionIds);
    final sessionLogoutTimes = List<String>.filled(
      sessionIds.length,
      DateTime.now().toIso8601String(),
    );

    await userRef.update({
      'active_session_ids': [],
      'session_logouttimes': sessionLogoutTimes,
      'active_sessions': 0,
      'last_logout_time': FieldValue.serverTimestamp(),
    });

    // Clear local session info
    FFAppState().currentSessionId = '';
    FFAppState().deviceModel = '';
    FFAppState().devicePlatform = '';

    return true;
  } catch (e) {
    print('Error logging out all sessions: $e');
    return false;
  }
}
