// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class ListWithScrollbar extends StatefulWidget {
  final List<dynamic> addresses; // Accept JSON data
  final double width;
  final double height;

  const ListWithScrollbar({
    Key? key,
    required this.addresses,
    this.width = double.infinity,
    this.height = 400.0, // Default height
  }) : super(key: key);

  @override
  _ListWithScrollbarState createState() => _ListWithScrollbarState();
}

class _ListWithScrollbarState extends State<ListWithScrollbar> {
  final ScrollController _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: Scrollbar(
        controller: _scrollController,
        thumbVisibility: true,
        child: ListView.builder(
          controller: _scrollController,
          itemCount: widget.addresses.length,
          itemBuilder: (context, index) {
            final address = widget.addresses[index] as Map<String, dynamic>;
            return ListTile(
              title: Text(address['name'] ?? 'No Name'),
              subtitle: Text(
                '${address['detailed_address'] ?? 'No Address'}, ${address['city'] ?? 'No City'}',
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
