// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_auth/firebase_auth.dart';

class SessionAutoLogout extends StatefulWidget {
  const SessionAutoLogout({
    Key? key,
    this.width,
    this.height,
  }) : super(key: key);

  final double? width;
  final double? height;

  @override
  _SessionAutoLogoutState createState() => _SessionAutoLogoutState();
}

class _SessionAutoLogoutState extends State<SessionAutoLogout> {
  bool _hasLoggedOut = false;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null || _hasLoggedOut) {
      return SizedBox(width: widget.width, height: widget.height);
    }

    final userRef = UsersRecord.collection.doc(user.uid);

    return StreamBuilder<UsersRecord>(
      stream: UsersRecord.getDocument(userRef),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return SizedBox(width: widget.width, height: widget.height);
        }

        final userDoc = snapshot.data!;
        final activeSessions = userDoc.activeSessionIds;
        final currentSessionId = FFAppState().currentSessionId;

        final isStillActive = activeSessions.contains(currentSessionId);

        if (!isStillActive && currentSessionId.isNotEmpty) {
          // Prevent multiple logout attempts
          _hasLoggedOut = true;

          // Clear app state
          FFAppState().currentSessionId = '';
          FFAppState().deviceModel = '';
          FFAppState().devicePlatform = '';

          // Log out and navigate
          Future.microtask(() async {
            await FirebaseAuth.instance.signOut();
            if (context.mounted) {
              context
                  .goNamed('Login'); // Replace with your login page route name
            }
          });
        }

        return SizedBox(width: widget.width, height: widget.height);
      },
    );
  }
}
