import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _nameApp = prefs.getString('ff_nameApp') ?? _nameApp;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _searchActive = false;
  bool get searchActive => _searchActive;
  set searchActive(bool value) {
    _searchActive = value;
  }

  String _address = '';
  String get address => _address;
  set address(String value) {
    _address = value;
  }

  String _nameApp = '';
  String get nameApp => _nameApp;
  set nameApp(String value) {
    _nameApp = value;
    prefs.setString('ff_nameApp', value);
  }

  String _location = '';
  String get location => _location;
  set location(String value) {
    _location = value;
  }

  String _currentSessionId = '';
  String get currentSessionId => _currentSessionId;
  set currentSessionId(String value) {
    _currentSessionId = value;
  }

  String _deviceModel = '';
  String get deviceModel => _deviceModel;
  set deviceModel(String value) {
    _deviceModel = value;
  }

  String _devicePlatform = '';
  String get devicePlatform => _devicePlatform;
  set devicePlatform(String value) {
    _devicePlatform = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
