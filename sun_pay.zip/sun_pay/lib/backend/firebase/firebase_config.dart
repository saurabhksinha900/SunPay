import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDLi434Elo7C-CBXfDx5_IWhG7Ea3OHqF0",
            authDomain: "sun-pay-qujura.firebaseapp.com",
            projectId: "sun-pay-qujura",
            storageBucket: "sun-pay-qujura.firebasestorage.app",
            messagingSenderId: "587717370897",
            appId: "1:587717370897:web:e667c883885a863705fdb0"));
  } else {
    await Firebase.initializeApp();
  }
}
