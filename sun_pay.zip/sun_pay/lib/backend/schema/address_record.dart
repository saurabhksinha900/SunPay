import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AddressRecord extends FirestoreRecord {
  AddressRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "phone" field.
  int? _phone;
  int get phone => _phone ?? 0;
  bool hasPhone() => _phone != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "detailed_address" field.
  String? _detailedAddress;
  String get detailedAddress => _detailedAddress ?? '';
  bool hasDetailedAddress() => _detailedAddress != null;

  // "City" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "State" field.
  String? _state;
  String get state => _state ?? '';
  bool hasState() => _state != null;

  // "Country" field.
  String? _country;
  String get country => _country ?? '';
  bool hasCountry() => _country != null;

  // "LatLng1" field.
  LatLng? _latLng1;
  LatLng? get latLng1 => _latLng1;
  bool hasLatLng1() => _latLng1 != null;

  // "ZipCode" field.
  String? _zipCode;
  String get zipCode => _zipCode ?? '';
  bool hasZipCode() => _zipCode != null;

  void _initializeFields() {
    _phone = castToType<int>(snapshotData['phone']);
    _type = snapshotData['type'] as String?;
    _detailedAddress = snapshotData['detailed_address'] as String?;
    _city = snapshotData['City'] as String?;
    _state = snapshotData['State'] as String?;
    _country = snapshotData['Country'] as String?;
    _latLng1 = snapshotData['LatLng1'] as LatLng?;
    _zipCode = snapshotData['ZipCode'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('address');

  static Stream<AddressRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => AddressRecord.fromSnapshot(s));

  static Future<AddressRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => AddressRecord.fromSnapshot(s));

  static AddressRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AddressRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AddressRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AddressRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AddressRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AddressRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAddressRecordData({
  int? phone,
  String? type,
  String? detailedAddress,
  String? city,
  String? state,
  String? country,
  LatLng? latLng1,
  String? zipCode,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'phone': phone,
      'type': type,
      'detailed_address': detailedAddress,
      'City': city,
      'State': state,
      'Country': country,
      'LatLng1': latLng1,
      'ZipCode': zipCode,
    }.withoutNulls,
  );

  return firestoreData;
}

class AddressRecordDocumentEquality implements Equality<AddressRecord> {
  const AddressRecordDocumentEquality();

  @override
  bool equals(AddressRecord? e1, AddressRecord? e2) {
    return e1?.phone == e2?.phone &&
        e1?.type == e2?.type &&
        e1?.detailedAddress == e2?.detailedAddress &&
        e1?.city == e2?.city &&
        e1?.state == e2?.state &&
        e1?.country == e2?.country &&
        e1?.latLng1 == e2?.latLng1 &&
        e1?.zipCode == e2?.zipCode;
  }

  @override
  int hash(AddressRecord? e) => const ListEquality().hash([
        e?.phone,
        e?.type,
        e?.detailedAddress,
        e?.city,
        e?.state,
        e?.country,
        e?.latLng1,
        e?.zipCode
      ]);

  @override
  bool isValidKey(Object? o) => o is AddressRecord;
}
