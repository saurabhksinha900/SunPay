import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BookingsRecord extends FirestoreRecord {
  BookingsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "user_id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "phone_number" field.
  int? _phoneNumber;
  int get phoneNumber => _phoneNumber ?? 0;
  bool hasPhoneNumber() => _phoneNumber != null;

  // "turf_id" field.
  String? _turfId;
  String get turfId => _turfId ?? '';
  bool hasTurfId() => _turfId != null;

  // "turf_name" field.
  String? _turfName;
  String get turfName => _turfName ?? '';
  bool hasTurfName() => _turfName != null;

  // "turf_location" field.
  String? _turfLocation;
  String get turfLocation => _turfLocation ?? '';
  bool hasTurfLocation() => _turfLocation != null;

  // "start_time" field.
  DateTime? _startTime;
  DateTime? get startTime => _startTime;
  bool hasStartTime() => _startTime != null;

  // "end_time" field.
  DateTime? _endTime;
  DateTime? get endTime => _endTime;
  bool hasEndTime() => _endTime != null;

  // "latlng1" field.
  LatLng? _latlng1;
  LatLng? get latlng1 => _latlng1;
  bool hasLatlng1() => _latlng1 != null;

  // "current_timestamp" field.
  DateTime? _currentTimestamp;
  DateTime? get currentTimestamp => _currentTimestamp;
  bool hasCurrentTimestamp() => _currentTimestamp != null;

  // "booking_location_name" field.
  String? _bookingLocationName;
  String get bookingLocationName => _bookingLocationName ?? '';
  bool hasBookingLocationName() => _bookingLocationName != null;

  // "booking_location_vicinity" field.
  String? _bookingLocationVicinity;
  String get bookingLocationVicinity => _bookingLocationVicinity ?? '';
  bool hasBookingLocationVicinity() => _bookingLocationVicinity != null;

  void _initializeFields() {
    _userId = snapshotData['user_id'] as String?;
    _phoneNumber = castToType<int>(snapshotData['phone_number']);
    _turfId = snapshotData['turf_id'] as String?;
    _turfName = snapshotData['turf_name'] as String?;
    _turfLocation = snapshotData['turf_location'] as String?;
    _startTime = snapshotData['start_time'] as DateTime?;
    _endTime = snapshotData['end_time'] as DateTime?;
    _latlng1 = snapshotData['latlng1'] as LatLng?;
    _currentTimestamp = snapshotData['current_timestamp'] as DateTime?;
    _bookingLocationName = snapshotData['booking_location_name'] as String?;
    _bookingLocationVicinity =
        snapshotData['booking_location_vicinity'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('bookings');

  static Stream<BookingsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BookingsRecord.fromSnapshot(s));

  static Future<BookingsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BookingsRecord.fromSnapshot(s));

  static BookingsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BookingsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BookingsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BookingsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BookingsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BookingsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBookingsRecordData({
  String? userId,
  int? phoneNumber,
  String? turfId,
  String? turfName,
  String? turfLocation,
  DateTime? startTime,
  DateTime? endTime,
  LatLng? latlng1,
  DateTime? currentTimestamp,
  String? bookingLocationName,
  String? bookingLocationVicinity,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user_id': userId,
      'phone_number': phoneNumber,
      'turf_id': turfId,
      'turf_name': turfName,
      'turf_location': turfLocation,
      'start_time': startTime,
      'end_time': endTime,
      'latlng1': latlng1,
      'current_timestamp': currentTimestamp,
      'booking_location_name': bookingLocationName,
      'booking_location_vicinity': bookingLocationVicinity,
    }.withoutNulls,
  );

  return firestoreData;
}

class BookingsRecordDocumentEquality implements Equality<BookingsRecord> {
  const BookingsRecordDocumentEquality();

  @override
  bool equals(BookingsRecord? e1, BookingsRecord? e2) {
    return e1?.userId == e2?.userId &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.turfId == e2?.turfId &&
        e1?.turfName == e2?.turfName &&
        e1?.turfLocation == e2?.turfLocation &&
        e1?.startTime == e2?.startTime &&
        e1?.endTime == e2?.endTime &&
        e1?.latlng1 == e2?.latlng1 &&
        e1?.currentTimestamp == e2?.currentTimestamp &&
        e1?.bookingLocationName == e2?.bookingLocationName &&
        e1?.bookingLocationVicinity == e2?.bookingLocationVicinity;
  }

  @override
  int hash(BookingsRecord? e) => const ListEquality().hash([
        e?.userId,
        e?.phoneNumber,
        e?.turfId,
        e?.turfName,
        e?.turfLocation,
        e?.startTime,
        e?.endTime,
        e?.latlng1,
        e?.currentTimestamp,
        e?.bookingLocationName,
        e?.bookingLocationVicinity
      ]);

  @override
  bool isValidKey(Object? o) => o is BookingsRecord;
}
