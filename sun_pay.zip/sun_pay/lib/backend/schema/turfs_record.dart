import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TurfsRecord extends FirestoreRecord {
  TurfsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "index" field.
  int? _index;
  int get index => _index ?? 0;
  bool hasIndex() => _index != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "img" field.
  String? _img;
  String get img => _img ?? '';
  bool hasImg() => _img != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "latlng1" field.
  LatLng? _latlng1;
  LatLng? get latlng1 => _latlng1;
  bool hasLatlng1() => _latlng1 != null;

  void _initializeFields() {
    _index = castToType<int>(snapshotData['index']);
    _name = snapshotData['name'] as String?;
    _city = snapshotData['city'] as String?;
    _img = snapshotData['img'] as String?;
    _category = snapshotData['category'] as String?;
    _description = snapshotData['description'] as String?;
    _latlng1 = snapshotData['latlng1'] as LatLng?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('turfs');

  static Stream<TurfsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TurfsRecord.fromSnapshot(s));

  static Future<TurfsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TurfsRecord.fromSnapshot(s));

  static TurfsRecord fromSnapshot(DocumentSnapshot snapshot) => TurfsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TurfsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TurfsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TurfsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TurfsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTurfsRecordData({
  int? index,
  String? name,
  String? city,
  String? img,
  String? category,
  String? description,
  LatLng? latlng1,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'index': index,
      'name': name,
      'city': city,
      'img': img,
      'category': category,
      'description': description,
      'latlng1': latlng1,
    }.withoutNulls,
  );

  return firestoreData;
}

class TurfsRecordDocumentEquality implements Equality<TurfsRecord> {
  const TurfsRecordDocumentEquality();

  @override
  bool equals(TurfsRecord? e1, TurfsRecord? e2) {
    return e1?.index == e2?.index &&
        e1?.name == e2?.name &&
        e1?.city == e2?.city &&
        e1?.img == e2?.img &&
        e1?.category == e2?.category &&
        e1?.description == e2?.description &&
        e1?.latlng1 == e2?.latlng1;
  }

  @override
  int hash(TurfsRecord? e) => const ListEquality().hash([
        e?.index,
        e?.name,
        e?.city,
        e?.img,
        e?.category,
        e?.description,
        e?.latlng1
      ]);

  @override
  bool isValidKey(Object? o) => o is TurfsRecord;
}
