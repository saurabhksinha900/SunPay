import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RecentSearchAddressRecord extends FirestoreRecord {
  RecentSearchAddressRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "address_name" field.
  String? _addressName;
  String get addressName => _addressName ?? '';
  bool hasAddressName() => _addressName != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "lat" field.
  double? _lat;
  double get lat => _lat ?? 0.0;
  bool hasLat() => _lat != null;

  // "lng" field.
  double? _lng;
  double get lng => _lng ?? 0.0;
  bool hasLng() => _lng != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  bool hasCountry() => _country != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  void _initializeFields() {
    _description = snapshotData['description'] as String?;
    _addressName = snapshotData['address_name'] as String?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _lat = castToType<double>(snapshotData['lat']);
    _lng = castToType<double>(snapshotData['lng']);
    _country = snapshotData['country'] as String?;
    _city = snapshotData['city'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('recent_search_address');

  static Stream<RecentSearchAddressRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RecentSearchAddressRecord.fromSnapshot(s));

  static Future<RecentSearchAddressRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => RecentSearchAddressRecord.fromSnapshot(s));

  static RecentSearchAddressRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RecentSearchAddressRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RecentSearchAddressRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RecentSearchAddressRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RecentSearchAddressRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RecentSearchAddressRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRecentSearchAddressRecordData({
  String? description,
  String? addressName,
  String? phoneNumber,
  double? lat,
  double? lng,
  String? country,
  String? city,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'description': description,
      'address_name': addressName,
      'phone_number': phoneNumber,
      'lat': lat,
      'lng': lng,
      'country': country,
      'city': city,
    }.withoutNulls,
  );

  return firestoreData;
}

class RecentSearchAddressRecordDocumentEquality
    implements Equality<RecentSearchAddressRecord> {
  const RecentSearchAddressRecordDocumentEquality();

  @override
  bool equals(RecentSearchAddressRecord? e1, RecentSearchAddressRecord? e2) {
    return e1?.description == e2?.description &&
        e1?.addressName == e2?.addressName &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.lat == e2?.lat &&
        e1?.lng == e2?.lng &&
        e1?.country == e2?.country &&
        e1?.city == e2?.city;
  }

  @override
  int hash(RecentSearchAddressRecord? e) => const ListEquality().hash([
        e?.description,
        e?.addressName,
        e?.phoneNumber,
        e?.lat,
        e?.lng,
        e?.country,
        e?.city
      ]);

  @override
  bool isValidKey(Object? o) => o is RecentSearchAddressRecord;
}
