import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "role" field.
  String? _role;
  String get role => _role ?? '';
  bool hasRole() => _role != null;

  // "session_ids" field.
  List<String>? _sessionIds;
  List<String> get sessionIds => _sessionIds ?? const [];
  bool hasSessionIds() => _sessionIds != null;

  // "session_devices" field.
  List<String>? _sessionDevices;
  List<String> get sessionDevices => _sessionDevices ?? const [];
  bool hasSessionDevices() => _sessionDevices != null;

  // "session_platforms" field.
  List<String>? _sessionPlatforms;
  List<String> get sessionPlatforms => _sessionPlatforms ?? const [];
  bool hasSessionPlatforms() => _sessionPlatforms != null;

  // "session_logintimes" field.
  List<String>? _sessionLogintimes;
  List<String> get sessionLogintimes => _sessionLogintimes ?? const [];
  bool hasSessionLogintimes() => _sessionLogintimes != null;

  // "last_logout_time" field.
  DateTime? _lastLogoutTime;
  DateTime? get lastLogoutTime => _lastLogoutTime;
  bool hasLastLogoutTime() => _lastLogoutTime != null;

  // "active_session_ids" field.
  List<String>? _activeSessionIds;
  List<String> get activeSessionIds => _activeSessionIds ?? const [];
  bool hasActiveSessionIds() => _activeSessionIds != null;

  // "session_logouttimes" field.
  List<String>? _sessionLogouttimes;
  List<String> get sessionLogouttimes => _sessionLogouttimes ?? const [];
  bool hasSessionLogouttimes() => _sessionLogouttimes != null;

  // "active_sessions" field.
  int? _activeSessions;
  int get activeSessions => _activeSessions ?? 0;
  bool hasActiveSessions() => _activeSessions != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _role = snapshotData['role'] as String?;
    _sessionIds = getDataList(snapshotData['session_ids']);
    _sessionDevices = getDataList(snapshotData['session_devices']);
    _sessionPlatforms = getDataList(snapshotData['session_platforms']);
    _sessionLogintimes = getDataList(snapshotData['session_logintimes']);
    _lastLogoutTime = snapshotData['last_logout_time'] as DateTime?;
    _activeSessionIds = getDataList(snapshotData['active_session_ids']);
    _sessionLogouttimes = getDataList(snapshotData['session_logouttimes']);
    _activeSessions = castToType<int>(snapshotData['active_sessions']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? role,
  DateTime? lastLogoutTime,
  int? activeSessions,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'role': role,
      'last_logout_time': lastLogoutTime,
      'active_sessions': activeSessions,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.role == e2?.role &&
        listEquality.equals(e1?.sessionIds, e2?.sessionIds) &&
        listEquality.equals(e1?.sessionDevices, e2?.sessionDevices) &&
        listEquality.equals(e1?.sessionPlatforms, e2?.sessionPlatforms) &&
        listEquality.equals(e1?.sessionLogintimes, e2?.sessionLogintimes) &&
        e1?.lastLogoutTime == e2?.lastLogoutTime &&
        listEquality.equals(e1?.activeSessionIds, e2?.activeSessionIds) &&
        listEquality.equals(e1?.sessionLogouttimes, e2?.sessionLogouttimes) &&
        e1?.activeSessions == e2?.activeSessions;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.role,
        e?.sessionIds,
        e?.sessionDevices,
        e?.sessionPlatforms,
        e?.sessionLogintimes,
        e?.lastLogoutTime,
        e?.activeSessionIds,
        e?.sessionLogouttimes,
        e?.activeSessions
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
