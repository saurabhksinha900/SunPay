import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TurfBookingsRecord extends FirestoreRecord {
  TurfBookingsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "turf_name" field.
  String? _turfName;
  String get turfName => _turfName ?? '';
  bool hasTurfName() => _turfName != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "start_slot_time" field.
  String? _startSlotTime;
  String get startSlotTime => _startSlotTime ?? '';
  bool hasStartSlotTime() => _startSlotTime != null;

  // "end_slot_time" field.
  String? _endSlotTime;
  String get endSlotTime => _endSlotTime ?? '';
  bool hasEndSlotTime() => _endSlotTime != null;

  // "phone_no" field.
  String? _phoneNo;
  String get phoneNo => _phoneNo ?? '';
  bool hasPhoneNo() => _phoneNo != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  void _initializeFields() {
    _turfName = snapshotData['turf_name'] as String?;
    _date = snapshotData['date'] as DateTime?;
    _startSlotTime = snapshotData['start_slot_time'] as String?;
    _endSlotTime = snapshotData['end_slot_time'] as String?;
    _phoneNo = snapshotData['phone_no'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('turf_bookings');

  static Stream<TurfBookingsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TurfBookingsRecord.fromSnapshot(s));

  static Future<TurfBookingsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TurfBookingsRecord.fromSnapshot(s));

  static TurfBookingsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TurfBookingsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TurfBookingsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TurfBookingsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TurfBookingsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TurfBookingsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTurfBookingsRecordData({
  String? turfName,
  DateTime? date,
  String? startSlotTime,
  String? endSlotTime,
  String? phoneNo,
  DateTime? createdAt,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'turf_name': turfName,
      'date': date,
      'start_slot_time': startSlotTime,
      'end_slot_time': endSlotTime,
      'phone_no': phoneNo,
      'created_at': createdAt,
    }.withoutNulls,
  );

  return firestoreData;
}

class TurfBookingsRecordDocumentEquality
    implements Equality<TurfBookingsRecord> {
  const TurfBookingsRecordDocumentEquality();

  @override
  bool equals(TurfBookingsRecord? e1, TurfBookingsRecord? e2) {
    return e1?.turfName == e2?.turfName &&
        e1?.date == e2?.date &&
        e1?.startSlotTime == e2?.startSlotTime &&
        e1?.endSlotTime == e2?.endSlotTime &&
        e1?.phoneNo == e2?.phoneNo &&
        e1?.createdAt == e2?.createdAt;
  }

  @override
  int hash(TurfBookingsRecord? e) => const ListEquality().hash([
        e?.turfName,
        e?.date,
        e?.startSlotTime,
        e?.endSlotTime,
        e?.phoneNo,
        e?.createdAt
      ]);

  @override
  bool isValidKey(Object? o) => o is TurfBookingsRecord;
}
