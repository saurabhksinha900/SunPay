import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

List<double>? convertLatLongToDouble(LatLng? location) {
  location ??= LatLng(0.0, 0.0);

  return [location.latitude, location.longitude];
}

LatLng? converDoubleToLatLong(
  double? lat,
  double? long,
) {
  lat ??= 0.0;
  long ??= 0.0;

  return LatLng(lat, long);
}

String? encodeURL(
  String? url,
  bool? encode,
) {
  url ??= '';
  encode ??= true;

  return encode ? Uri.encodeComponent(url) : Uri.decodeComponent(url);
}

List<int> generateIndexes(int count) {
  return List<int>.generate(count, (i) => i);
}

String computeDistance(
  double lat1,
  double lon1,
  double lat2,
  double lon2,
) {
  const R = 6371; // Radius of the Earth in kilometers

  // Convert degrees to radians
  double dLat = _degToRad(lat2 - lat1);
  double dLon = _degToRad(lon2 - lon1);

  // Haversine formula
  double a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(_degToRad(lat1)) *
          math.cos(_degToRad(lat2)) *
          math.sin(dLon / 2) *
          math.sin(dLon / 2);
  double c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));

  double distance = R * c;

// Return distance as string with " km"
  return '${distance.toStringAsFixed(2)} km';
}

// Helper function to convert degrees to radians
double _degToRad(double deg) {
  return deg * (math.pi / 180);
}
