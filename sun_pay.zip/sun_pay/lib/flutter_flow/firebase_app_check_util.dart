import 'package:firebase_app_check/firebase_app_check.dart';

Future initializeFirebaseAppCheck() => FirebaseAppCheck.instance.activate(
      webProvider: ReCaptchaEnterpriseProvider(
          '6LfPgNkqAAAAAC8U6Zx5HnHd1k1IxGEAlfdVxuM_'),
      androidProvider: AndroidProvider.playIntegrity,
    );
