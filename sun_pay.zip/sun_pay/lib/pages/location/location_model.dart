import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'dart:async';
import 'location_widget.dart' show LocationWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LocationModel extends FlutterFlowModel<LocationWidget> {
  ///  Local state fields for this page.

  List<dynamic> value = [];
  void addToValue(dynamic item) => value.add(item);
  void removeFromValue(dynamic item) => value.remove(item);
  void removeAtIndexFromValue(int index) => value.removeAt(index);
  void insertAtIndexInValue(int index, dynamic item) =>
      value.insert(index, item);
  void updateValueAtIndex(int index, Function(dynamic) updateFn) =>
      value[index] = updateFn(value[index]);

  String? street;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (Get Current Location)] action in location widget.
  ApiCallResponse? apiResult2o5;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - API (Get Place Id)] action in TextField widget.
  ApiCallResponse? apiResultwgm;
  // Stores action output result for [Custom Action - startSpeechToText] action in Icon widget.
  String? speechtotext;
  // Stores action output result for [Backend Call - API (Get Place Details)] action in Column widget.
  ApiCallResponse? apiResulto5r;
  Completer<ApiCallResponse>? apiRequestCompleter;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }

  /// Additional helper methods.
  Future waitForApiRequestCompleted({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = apiRequestCompleter?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}
