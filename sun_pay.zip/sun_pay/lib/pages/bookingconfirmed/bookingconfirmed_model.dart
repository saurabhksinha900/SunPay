import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'bookingconfirmed_widget.dart' show BookingconfirmedWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BookingconfirmedModel extends FlutterFlowModel<BookingconfirmedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
