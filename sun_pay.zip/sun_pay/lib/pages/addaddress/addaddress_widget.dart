import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_place_picker.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/place.dart';
import 'dart:async';
import 'dart:io';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'addaddress_model.dart';
export 'addaddress_model.dart';

class AddaddressWidget extends StatefulWidget {
  const AddaddressWidget({
    super.key,
    this.originaladdress,
  });

  final String? originaladdress;

  static String routeName = 'addaddress';
  static String routePath = '/addaddress';

  @override
  State<AddaddressWidget> createState() => _AddaddressWidgetState();
}

class _AddaddressWidgetState extends State<AddaddressWidget> {
  late AddaddressModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  LatLng? currentUserLocationValue;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AddaddressModel());

    logFirebaseEvent('screen_view', parameters: {'screen_name': 'addaddress'});
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('ADDADDRESS_PAGE_addaddress_ON_INIT_STATE');
      currentUserLocationValue =
          await getCurrentUserLocation(defaultLocation: LatLng(0.0, 0.0));
      logFirebaseEvent('addaddress_backend_call');
      _model.apiResultrb4 = await GetCurrentLocationCall.call(
        lat: functions
            .convertLatLongToDouble(currentUserLocationValue)
            ?.firstOrNull,
        lng: functions
            .convertLatLongToDouble(currentUserLocationValue)
            ?.lastOrNull,
      );

      if ((_model.apiResultrb4?.succeeded ?? true)) {
        logFirebaseEvent('addaddress_update_page_state');
        _model.currentlocation = GetCurrentLocationCall.address(
          (_model.apiResultrb4?.jsonBody ?? ''),
        )?.firstOrNull;
        safeSetState(() {});
      }
    });

    getCurrentUserLocation(defaultLocation: LatLng(0.0, 0.0), cached: true)
        .then((loc) => safeSetState(() => currentUserLocationValue = loc));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (currentUserLocationValue == null) {
      return Container(
        color: FlutterFlowTheme.of(context).primaryBackground,
        child: Center(
          child: SizedBox(
            width: 50.0,
            height: 50.0,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(
                FlutterFlowTheme.of(context).primary,
              ),
            ),
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 20.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        logFirebaseEvent(
                            'ADDADDRESS_PAGE_Icon_oznhshef_ON_TAP');
                        logFirebaseEvent('Icon_navigate_to');

                        context.pushNamed(SavedaddressesWidget.routeName);
                      },
                      child: Icon(
                        Icons.arrow_back,
                        color: FlutterFlowTheme.of(context).primaryText,
                        size: 24.0,
                      ),
                    ),
                    FlutterFlowPlacePicker(
                      iOSGoogleMapsApiKey:
                          'AIzaSyD7K1raDMh9cImsprcyD3KTUGDYhTS6Jns',
                      androidGoogleMapsApiKey:
                          'AIzaSyDi_LEBlgdkAQ1tXCXjifpxP3Znf5P71fY',
                      webGoogleMapsApiKey:
                          'AIzaSyBehjtvxjviLWNQdQtbl00xmpMR5IdPo_Y',
                      onSelect: (place) async {
                        safeSetState(() => _model.placePickerValue = place);
                      },
                      defaultText: 'Select Location',
                      icon: Icon(
                        Icons.place,
                        color: FlutterFlowTheme.of(context).info,
                        size: 16.0,
                      ),
                      buttonOptions: FFButtonOptions(
                        width: 200.0,
                        height: 40.0,
                        color: FlutterFlowTheme.of(context).primary,
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  font: GoogleFonts.interTight(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                                  color: FlutterFlowTheme.of(context).info,
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontStyle,
                                ),
                        elevation: 0.0,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(120.0, 0.0, 0.0, 0.0),
                      child: FlutterFlowIconButton(
                        borderRadius: 8.0,
                        buttonSize: 40.0,
                        fillColor: FlutterFlowTheme.of(context).primary,
                        icon: Icon(
                          Icons.search,
                          color: FlutterFlowTheme.of(context).info,
                          size: 24.0,
                        ),
                        onPressed: () async {
                          logFirebaseEvent('ADDADDRESS_PAGE_search_ICN_ON_TAP');
                          logFirebaseEvent('IconButton_google_map');
                          unawaited(
                            () async {
                              await _model.googleMapsController.future.then(
                                (c) => c.animateCamera(
                                  CameraUpdate.newLatLng(_model
                                      .placePickerValue.latLng
                                      .toGoogleMaps()),
                                ),
                              );
                            }(),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                child: Text(
                  valueOrDefault<String>(
                    () {
                      if (_model.placePickerValue.address != null &&
                          _model.placePickerValue.address != '') {
                        return _model.placePickerValue.address;
                      } else if (widget!.originaladdress != null &&
                          widget!.originaladdress != '') {
                        return widget!.originaladdress;
                      } else {
                        return _model.currentlocation;
                      }
                    }(),
                    'Test4 JP2F+F25, Phase 1, Hinjawadi Rajiv Gandhi Infotech Park, Hinjawadi, Pune, Pimpri-Chinchwad, Maharashtra 411057, India',
                  ),
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.inter(
                          fontWeight: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                child: FlutterFlowChoiceChips(
                  options: [
                    ChipData('Home', Icons.home),
                    ChipData('Work', Icons.work),
                    ChipData('Hotel', Icons.hotel),
                    ChipData('Other', Icons.location_on)
                  ],
                  onChanged: (val) => safeSetState(
                      () => _model.choiceChipsValue = val?.firstOrNull),
                  selectedChipStyle: ChipStyle(
                    backgroundColor: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                          font: GoogleFonts.inter(
                            fontWeight: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontStyle,
                          ),
                          color: FlutterFlowTheme.of(context).info,
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                    iconColor: FlutterFlowTheme.of(context).info,
                    iconSize: 16.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  unselectedChipStyle: ChipStyle(
                    backgroundColor:
                        FlutterFlowTheme.of(context).secondaryBackground,
                    textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                          font: GoogleFonts.inter(
                            fontWeight: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontStyle,
                          ),
                          color: FlutterFlowTheme.of(context).secondaryText,
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                    iconColor: FlutterFlowTheme.of(context).secondaryText,
                    iconSize: 16.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  chipSpacing: 8.0,
                  rowSpacing: 8.0,
                  multiselect: false,
                  initialized: _model.choiceChipsValue != null,
                  alignment: WrapAlignment.start,
                  controller: _model.choiceChipsValueController ??=
                      FormFieldController<List<String>>(
                    ['Home'],
                  ),
                  wrapped: true,
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                child: FFButtonWidget(
                  onPressed: () async {
                    logFirebaseEvent('ADDADDRESS_SAVE_AND_PROCEED_BTN_ON_TAP');
                    logFirebaseEvent('Button_update_app_state');
                    FFAppState().location = valueOrDefault<String>(
                      _model.placePickerValue.address != null &&
                              _model.placePickerValue.address != ''
                          ? valueOrDefault<String>(
                              _model.placePickerValue.address,
                              'Test3 JP2F+F25, Phase 1, Hinjawadi Rajiv Gandhi Infotech Park, Hinjawadi, Pune, Pimpri-Chinchwad, Maharashtra 411057, India',
                            )
                          : widget!.originaladdress,
                      'Test4 JP2F+F25, Phase 1, Hinjawadi Rajiv Gandhi Infotech Park, Hinjawadi, Pune, Pimpri-Chinchwad, Maharashtra 411057, India',
                    );
                    FFAppState().update(() {});
                    logFirebaseEvent('Button_wait__delay');
                    await Future.delayed(const Duration(milliseconds: 200));
                    if (widget!.originaladdress != null &&
                        widget!.originaladdress != '') {
                      logFirebaseEvent('Button_firestore_query');
                      _model.toupdateaddress = await queryAddressRecordOnce(
                        queryBuilder: (addressRecord) => addressRecord.where(
                          'detailed_address',
                          isEqualTo: widget!.originaladdress,
                        ),
                        singleRecord: true,
                      ).then((s) => s.firstOrNull);
                      logFirebaseEvent('Button_backend_call');

                      await _model.toupdateaddress!.reference
                          .update(createAddressRecordData(
                        type: _model.choiceChipsValue,
                        detailedAddress:
                            _model.placePickerValue.address != null &&
                                    _model.placePickerValue.address != ''
                                ? _model.placePickerValue.address
                                : widget!.originaladdress,
                        city: _model.placePickerValue.city,
                        state: _model.placePickerValue.state,
                        country: _model.placePickerValue.country,
                        latLng1: _model.placePickerValue.latLng,
                        zipCode: _model.placePickerValue.zipCode,
                      ));
                      logFirebaseEvent('Button_navigate_to');
                      if (Navigator.of(context).canPop()) {
                        context.pop();
                      }
                      context.pushNamed(SavedaddressesWidget.routeName);
                    } else {
                      logFirebaseEvent('Button_backend_call');

                      await AddressRecord.collection
                          .doc()
                          .set(createAddressRecordData(
                            phone: 917709019535,
                            type: _model.choiceChipsValue,
                            detailedAddress: _model.placePickerValue.address,
                            city: _model.placePickerValue.city,
                            state: _model.placePickerValue.state,
                            country: _model.placePickerValue.country,
                            latLng1: _model.placePickerValue.latLng,
                            zipCode: _model.placePickerValue.zipCode,
                          ));
                      logFirebaseEvent('Button_navigate_to');
                      if (Navigator.of(context).canPop()) {
                        context.pop();
                      }
                      context.pushNamed(SavedaddressesWidget.routeName);
                    }

                    safeSetState(() {});
                  },
                  text: 'SAVE AND PROCEED',
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          font: GoogleFonts.interTight(
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontStyle,
                          ),
                          color: Colors.white,
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleSmall
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleSmall.fontStyle,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(),
                  child: FlutterFlowGoogleMap(
                    controller: _model.googleMapsController,
                    onCameraIdle: (latLng) => _model.googleMapsCenter = latLng,
                    initialLocation: _model.googleMapsCenter ??=
                        currentUserLocationValue!,
                    markerColor: GoogleMarkerColor.violet,
                    mapType: MapType.normal,
                    style: GoogleMapStyle.standard,
                    initialZoom: 14.0,
                    allowInteraction: true,
                    allowZoom: true,
                    showZoomControls: true,
                    showLocation: true,
                    showCompass: false,
                    showMapToolbar: false,
                    showTraffic: false,
                    centerMapOnMarkerTap: true,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
