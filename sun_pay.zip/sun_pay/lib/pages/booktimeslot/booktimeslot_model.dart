import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'booktimeslot_widget.dart' show BooktimeslotWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BooktimeslotModel extends FlutterFlowModel<BooktimeslotWidget> {
  ///  Local state fields for this page.

  List<DateTime> availableDates = [];
  void addToAvailableDates(DateTime item) => availableDates.add(item);
  void removeFromAvailableDates(DateTime item) => availableDates.remove(item);
  void removeAtIndexFromAvailableDates(int index) =>
      availableDates.removeAt(index);
  void insertAtIndexInAvailableDates(int index, DateTime item) =>
      availableDates.insert(index, item);
  void updateAvailableDatesAtIndex(int index, Function(DateTime) updateFn) =>
      availableDates[index] = updateFn(availableDates[index]);

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Firestore Query - Query a collection] action in booktimeslot widget.
  List<SolarBookingsRecord>? abc;
  // State field(s) for Calendar widget.
  DateTimeRange? calendarSelectedDay;

  @override
  void initState(BuildContext context) {
    calendarSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  @override
  void dispose() {}
}
