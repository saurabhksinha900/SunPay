import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'te2_widget.dart' show Te2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Te2Model extends FlutterFlowModel<Te2Widget> {
  ///  Local state fields for this page.

  LatLng? location;

  String? street;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (Get Current Location)] action in Button widget.
  ApiCallResponse? apiResultizi;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
