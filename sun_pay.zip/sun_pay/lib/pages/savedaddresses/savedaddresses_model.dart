import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'savedaddresses_widget.dart' show SavedaddressesWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

class SavedaddressesModel extends FlutterFlowModel<SavedaddressesWidget> {
  ///  Local state fields for this page.

  List<dynamic> value = [];
  void addToValue(dynamic item) => value.add(item);
  void removeFromValue(dynamic item) => value.remove(item);
  void removeAtIndexFromValue(int index) => value.removeAt(index);
  void insertAtIndexInValue(int index, dynamic item) =>
      value.insert(index, item);
  void updateValueAtIndex(int index, Function(dynamic) updateFn) =>
      value[index] = updateFn(value[index]);

  String? street;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (Get Current Location)] action in savedaddresses widget.
  ApiCallResponse? apiResult2o5;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - API (Get Place Id)] action in TextField widget.
  ApiCallResponse? apiResultwgm;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
